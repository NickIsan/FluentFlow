
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  ChevronRight, 
  Check, 
  ShieldCheck, 
  ShoppingCart, 
  Calendar as CalendarIcon, 
  Clock, 
  ChevronLeft,
  CreditCard,
  Zap,
  Star
} from 'lucide-react';
import { Subject, DayAvailability, Language } from '../types';
import { translations } from '../translations';

interface BookingViewProps {
  onComplete: (subject: string, date: Date, price: number, packageSize: number) => void;
  subjects: Subject[];
  availability: DayAvailability[];
  language: Language;
  userCredits: number;
}

const PACKAGES = [
  { size: 1, label_en: "Single Lesson", label_el: "Μονό Μάθημα", discount: 0, tag: "Trial" },
  { size: 5, label_en: "5 Lessons Pack", label_el: "Πακέτο 5 Μαθημάτων", discount: 5, tag: "Popular" },
  { size: 10, label_en: "10 Lessons Pack", label_el: "Πακέτο 10 Μαθημάτων", discount: 15, tag: "Best Value" },
];

export const BookingView: React.FC<BookingViewProps> = ({ onComplete, subjects, availability, language, userCredits }) => {
  const t = translations[language];
  const [step, setStep] = useState<1 | 2 | 3>(userCredits > 0 ? 2 : 1);
  const [selectedSubject, setSelectedSubject] = useState<Subject>(subjects[0]);
  const [selectedPack, setSelectedPack] = useState(PACKAGES[0]);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTime, setSelectedTime] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const paypalRef = useRef<HTMLDivElement>(null);

  // Generate next 14 days
  const nextDays = useMemo(() => {
    const days = [];
    for (let i = 0; i < 14; i++) {
      const d = new Date();
      d.setDate(d.getDate() + i);
      days.push({
        full: d.toISOString().split('T')[0],
        dayName: d.toLocaleDateString('en-US', { weekday: 'long' }),
        shortDay: d.toLocaleDateString(language, { weekday: 'short' }),
        dateNum: d.getDate()
      });
    }
    return days;
  }, [language]);

  const totalPrice = useMemo(() => {
    const base = selectedSubject.price * selectedPack.size;
    return base - (base * (selectedPack.discount / 100));
  }, [selectedSubject, selectedPack]);

  const availableSlots = useMemo(() => {
    if (!selectedDate) return [];
    const dayName = nextDays.find(d => d.full === selectedDate)?.dayName;
    const dayConfig = availability.find(a => a.day === dayName);
    if (!dayConfig || !dayConfig.enabled) return [];
    
    const slots = [];
    let startHour = parseInt(dayConfig.start.split(':')[0]);
    let endHour = parseInt(dayConfig.end.split(':')[0]);
    for (let i = startHour; i < endHour; i++) slots.push(`${i.toString().padStart(2, '0')}:00`);
    return slots;
  }, [selectedDate, availability, nextDays]);

  useEffect(() => {
    if (showPayment && (window as any).paypal && paypalRef.current) {
      paypalRef.current.innerHTML = "";
      (window as any).paypal.Buttons({
        style: { layout: 'vertical', color: 'blue', shape: 'rect', label: 'pay', borderRadius: 12 },
        createOrder: (data: any, actions: any) => {
          return actions.order.create({
            purchase_units: [{
              description: `${selectedPack.label_en}: ${selectedSubject.name}`,
              amount: { currency_code: 'USD', value: totalPrice.toFixed(2) }
            }]
          });
        },
        onApprove: async (data: any, actions: any) => {
          await actions.order.capture();
          finishBooking();
        }
      }).render(paypalRef.current);
    }
  }, [showPayment, totalPrice]);

  const finishBooking = () => {
    setIsSuccess(true);
    const d = new Date(selectedDate + " " + selectedTime);
    onComplete(selectedSubject.name, d, totalPrice, selectedPack.size);
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center py-32 animate-in zoom-in duration-500">
        <div className="w-24 h-24 bg-emerald-500 text-white rounded-full flex items-center justify-center mb-8 shadow-2xl shadow-emerald-200">
          <Check size={48} strokeWidth={3} />
        </div>
        <h2 className="text-4xl font-black text-slate-900 text-center mb-4">{t.successPay}</h2>
        <p className="text-slate-500 font-medium">Your lesson is confirmed. Check your dashboard!</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Step Indicator */}
      <div className="flex items-center gap-4 mb-12 overflow-x-auto pb-2">
        <StepIndicator num={1} label="Choose Package" active={step === 1} completed={step > 1} onClick={() => setStep(1)} />
        <div className="w-12 h-[2px] bg-slate-200" />
        <StepIndicator num={2} label="Schedule" active={step === 2} completed={step > 2} onClick={() => selectedPack && setStep(2)} />
        <div className="w-12 h-[2px] bg-slate-200" />
        <StepIndicator num={3} label="Checkout" active={step === 3} completed={step > 3} onClick={() => selectedDate && selectedTime && setStep(3)} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
        
        {/* Left Column: Form Content */}
        <div className="lg:col-span-2 space-y-10">
          
          {step === 1 && (
            <div className="space-y-8 animate-in slide-in-from-left duration-500">
              <div className="space-y-2">
                <h2 className="text-3xl font-black text-slate-900">Select a Package</h2>
                <p className="text-slate-500">Get better rates by booking more sessions in advance.</p>
              </div>
              <div className="grid grid-cols-1 gap-4">
                {PACKAGES.map(p => (
                  <button 
                    key={p.size} 
                    onClick={() => setSelectedPack(p)}
                    className={`group relative p-6 rounded-3xl border-2 transition-all flex items-center justify-between ${
                      selectedPack.size === p.size 
                      ? 'border-indigo-600 bg-indigo-50/50 ring-4 ring-indigo-100' 
                      : 'border-slate-100 bg-white hover:border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-6">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${selectedPack.size === p.size ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-400'}`}>
                        <Zap size={24} fill={selectedPack.size === p.size ? 'currentColor' : 'none'} />
                      </div>
                      <div className="text-left">
                        <span className="block font-black text-lg text-slate-900">{language === 'el' ? p.label_el : p.label_en}</span>
                        <span className="text-slate-500 text-sm font-medium">Valid for all subjects</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="block font-black text-2xl text-slate-900">
                        ${(selectedSubject.price * p.size * (1 - p.discount/100)).toFixed(0)}
                      </span>
                      {p.discount > 0 && (
                        <span className="text-xs font-black text-emerald-600 bg-emerald-100 px-2 py-1 rounded-full">SAVE {p.discount}%</span>
                      )}
                    </div>
                    {p.tag && (
                      <span className="absolute -top-3 left-6 px-3 py-1 bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest rounded-full">
                        {p.tag}
                      </span>
                    )}
                  </button>
                ))}
              </div>
              <button 
                onClick={() => setStep(2)}
                className="w-full lg:w-auto px-10 py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center justify-center gap-3"
              >
                Next Step <ChevronRight size={20} />
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-10 animate-in slide-in-from-right duration-500">
              <div className="space-y-2">
                <button onClick={() => setStep(1)} className="text-indigo-600 font-bold flex items-center gap-1 mb-4 hover:gap-2 transition-all">
                  <ChevronLeft size={18} /> Back to packages
                </button>
                <h2 className="text-3xl font-black text-slate-900">Choose your Time</h2>
                <p className="text-slate-500">Select a date from the calendar to see available slots.</p>
              </div>

              {/* Custom Date Picker */}
              <div className="space-y-4">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2">
                  <CalendarIcon size={14} /> 1. Select Date
                </label>
                <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide">
                  {nextDays.map(d => (
                    <button
                      key={d.full}
                      onClick={() => setSelectedDate(d.full)}
                      className={`flex-shrink-0 w-20 h-24 rounded-3xl border-2 flex flex-col items-center justify-center transition-all ${
                        selectedDate === d.full
                        ? 'border-indigo-600 bg-indigo-600 text-white shadow-lg shadow-indigo-100'
                        : 'border-slate-100 bg-white text-slate-500 hover:border-slate-200'
                      }`}
                    >
                      <span className="text-[10px] font-black uppercase tracking-tighter mb-1 opacity-70">{d.shortDay}</span>
                      <span className="text-2xl font-black">{d.dateNum}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Slots */}
              {selectedDate && (
                <div className="space-y-4 animate-in fade-in slide-in-from-top-4">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2">
                    <Clock size={14} /> 2. Select Time (Local)
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                    {availableSlots.map(t => (
                      <button
                        key={t}
                        onClick={() => setSelectedTime(t)}
                        className={`p-4 rounded-2xl border-2 font-bold transition-all ${
                          selectedTime === t
                          ? 'border-indigo-600 bg-indigo-600 text-white shadow-lg shadow-indigo-100'
                          : 'border-slate-100 bg-white text-slate-900 hover:border-slate-200'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                    {availableSlots.length === 0 && (
                      <div className="col-span-full p-8 bg-slate-50 rounded-3xl border border-dashed border-slate-200 text-center text-slate-400 font-medium">
                        No availability for this day. Try another one!
                      </div>
                    )}
                  </div>
                </div>
              )}

              <button 
                disabled={!selectedDate || !selectedTime}
                onClick={() => setStep(3)}
                className="w-full lg:w-auto px-10 py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center justify-center gap-3 disabled:opacity-20"
              >
                Confirm Schedule <ChevronRight size={20} />
              </button>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-10 animate-in slide-in-from-bottom-4 duration-500">
               <div className="space-y-2">
                <button onClick={() => setStep(2)} className="text-indigo-600 font-bold flex items-center gap-1 mb-4 hover:gap-2 transition-all">
                  <ChevronLeft size={18} /> Edit schedule
                </button>
                <h2 className="text-3xl font-black text-slate-900">Secure Checkout</h2>
                <p className="text-slate-500">Confirm your details and choose payment method.</p>
              </div>

              <div className="bg-white rounded-[2rem] border border-slate-100 p-8 space-y-6">
                <div className="flex items-center gap-6 pb-6 border-b border-slate-50">
                  <div className="w-20 h-20 rounded-2xl bg-indigo-600 flex items-center justify-center text-white text-3xl font-black">
                    {selectedPack.size}
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-slate-900">{selectedPack.label_en}</h4>
                    <p className="text-slate-500 font-medium">{selectedSubject.name}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-4">
                    <CalendarIcon size={20} className="text-indigo-600" />
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase">First Lesson</p>
                      <p className="font-bold text-slate-900">{new Date(selectedDate).toLocaleDateString(language, { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                    </div>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-4">
                    <Clock size={20} className="text-indigo-600" />
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase">Start Time</p>
                      <p className="font-bold text-slate-900">{selectedTime}</p>
                    </div>
                  </div>
                </div>
              </div>

              {userCredits >= 1 ? (
                <div className="bg-emerald-50 border border-emerald-100 p-8 rounded-3xl space-y-4">
                  <div className="flex items-center gap-3 text-emerald-700 font-black">
                    <Check className="bg-emerald-500 text-white rounded-full p-1" size={24} />
                    You have existing credits!
                  </div>
                  <p className="text-emerald-600/80 font-medium">We'll use 1 credit from your balance for this booking. No payment required.</p>
                  <button onClick={finishBooking} className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black text-lg shadow-xl shadow-emerald-200">Book with Credit</button>
                </div>
              ) : (
                <div className="space-y-6">
                   {!showPayment ? (
                      <button onClick={() => setShowPayment(true)} className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black text-lg shadow-xl shadow-indigo-200 flex items-center justify-center gap-3">
                        <CreditCard size={20} /> Proceed to Payment
                      </button>
                   ) : (
                      <div className="animate-in zoom-in-95">
                        <div ref={paypalRef} className="min-h-[200px]" />
                        <button onClick={() => setShowPayment(false)} className="w-full text-center text-slate-400 font-bold mt-4 hover:text-slate-600 transition-colors">Cancel Payment</button>
                      </div>
                   )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Order Summary */}
        <div className="lg:sticky lg:top-10 space-y-6">
           <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white shadow-2xl space-y-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-5">
                <ShoppingCart size={120} />
              </div>
              <h3 className="text-2xl font-black border-b border-white/10 pb-6">Summary</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center text-slate-400 font-medium">
                  <span>Price per session</span>
                  <span>${selectedSubject.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-slate-400 font-medium">
                  <span>Quantity</span>
                  <span>x{selectedPack.size}</span>
                </div>
                {selectedPack.discount > 0 && (
                  <div className="flex justify-between items-center text-emerald-400 font-bold">
                    <span>Discount ({selectedPack.discount}%)</span>
                    <span>-${(selectedSubject.price * selectedPack.size * (selectedPack.discount/100)).toFixed(2)}</span>
                  </div>
                )}
                <div className="pt-6 border-t border-white/10 flex justify-between items-center">
                  <span className="text-lg font-bold">Total</span>
                  <span className="text-3xl font-black text-indigo-400">${totalPrice.toFixed(2)}</span>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 bg-white/5 rounded-2xl border border-white/10">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center"><Star size={20} fill="white" /></div>
                <div className="text-xs">
                  <p className="font-black">FluentFlow Guarantee</p>
                  <p className="text-white/50">100% refund if teacher doesn't show up.</p>
                </div>
              </div>
           </div>
           <div className="flex items-center justify-center gap-4 text-slate-400">
             <ShieldCheck size={20} />
             <span className="text-[10px] font-black uppercase tracking-widest">PCI-DSS Secure Payment</span>
           </div>
        </div>
      </div>
    </div>
  );
};

const StepIndicator: React.FC<{ num: number; label: string; active: boolean; completed: boolean; onClick: () => void }> = ({ num, label, active, completed, onClick }) => (
  <button 
    onClick={onClick}
    disabled={!completed && !active}
    className="flex items-center gap-3 flex-shrink-0 transition-all disabled:opacity-30"
  >
    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all ${
      active ? 'bg-indigo-600 text-white shadow-lg ring-4 ring-indigo-100' : 
      completed ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-500'
    }`}>
      {completed ? <Check size={14} strokeWidth={3} /> : num}
    </div>
    <span className={`text-sm font-black whitespace-nowrap ${active ? 'text-slate-900' : 'text-slate-400'}`}>{label}</span>
  </button>
);
