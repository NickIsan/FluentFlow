
import React, { useState } from 'react';
import { User, UserRole, RegisteredUser, Language } from '../types';
import { translations } from '../translations';
import { Zap, User as UserIcon, GraduationCap, ChevronRight, Mail, Lock, Key, RefreshCw } from 'lucide-react';

interface LoginViewProps {
  onLogin: (user: User) => void;
  onSignUp: (user: RegisteredUser) => void;
  onResetPassword: (email: string, newPass: string) => void;
  registeredUsers: RegisteredUser[];
  onSendCode: (email: string, code: string) => void;
  language: Language;
}

export const LoginView: React.FC<LoginViewProps> = ({ 
  onLogin, 
  onSignUp, 
  onResetPassword, 
  registeredUsers, 
  onSendCode,
  language 
}) => {
  const t = translations[language];
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [resetStep, setResetStep] = useState<1 | 2 | 3>(1); // 1: Email, 2: Code, 3: New Pass
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<UserRole>('student');
  const [teacherCode, setTeacherCode] = useState("");
  const [resetCodeInput, setResetCodeInput] = useState("");
  const [generatedCode, setGeneratedCode] = useState("");
  const [error, setError] = useState("");

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const found = registeredUsers.find(u => u.email === email && u.passwordHash === password);
    if (found) {
      onLogin({ id: found.id, name: found.name, email: found.email, role: found.role, credits: found.credits });
    } else {
      setError(language === 'el' ? "Λάθος στοιχεία." : "Invalid credentials.");
    }
  };

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (role === 'teacher' && teacherCode !== "121206") {
      setError(language === 'el' ? "Ο κωδικός δασκάλου είναι λανθασμένος." : "Invalid teacher code.");
      return;
    }
    if (registeredUsers.some(u => u.email === email)) {
      setError(language === 'el' ? "Το email υπάρχει ήδη." : "Email already exists.");
      return;
    }
    onSignUp({ id: Math.random().toString(36).substr(2, 9), name, email, role, passwordHash: password, credits: 0 });
  };

  const handleForgotStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    const user = registeredUsers.find(u => u.email === email);
    if (!user) {
      setError(t.userNotFound);
      return;
    }
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedCode(code);
    onSendCode(email, code);
    setResetStep(2);
    setError("");
  };

  const handleForgotStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    if (resetCodeInput === generatedCode) {
      setResetStep(3);
      setError("");
    } else {
      setError(t.invalidCode);
    }
  };

  const handleForgotStep3 = (e: React.FormEvent) => {
    e.preventDefault();
    onResetPassword(email, password);
    setMode('login');
    setResetStep(1);
    setError("");
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')]">
      <div className="max-w-md w-full animate-in fade-in zoom-in duration-700">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-indigo-600 rounded-[2rem] text-white shadow-2xl shadow-indigo-500/50 mb-6 rotate-3">
            <Zap size={40} fill="currentColor" />
          </div>
          <h1 className="text-4xl font-black text-white tracking-tight">FluentFlow</h1>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 md:p-10 rounded-[2.5rem] shadow-2xl space-y-8">
          {mode !== 'forgot' && (
            <div className="flex bg-white/5 p-1 rounded-2xl">
              <button onClick={() => { setMode('login'); setError(""); }} className={`flex-1 py-3 rounded-xl font-bold transition-all ${mode === 'login' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400'}`}>{t.login}</button>
              <button onClick={() => { setMode('signup'); setError(""); }} className={`flex-1 py-3 rounded-xl font-bold transition-all ${mode === 'signup' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400'}`}>{t.signup}</button>
            </div>
          )}

          {error && <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-2xl text-xs font-bold animate-in shake">{error}</div>}

          {mode === 'forgot' ? (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-white text-center">{t.resetPass}</h2>
              <form onSubmit={resetStep === 1 ? handleForgotStep1 : resetStep === 2 ? handleForgotStep2 : handleForgotStep3} className="space-y-6">
                {resetStep === 1 && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-1">{t.enterEmail}</label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                      <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@example.com" className="w-full p-4 pl-12 rounded-2xl bg-white/5 border border-white/10 text-white outline-none font-bold" />
                    </div>
                  </div>
                )}
                {resetStep === 2 && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-1">{t.resetCode}</label>
                    <div className="relative">
                      <RefreshCw className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                      <input type="text" required value={resetCodeInput} onChange={(e) => setResetCodeInput(e.target.value)} placeholder="0000" className="w-full p-4 pl-12 rounded-2xl bg-white/5 border border-white/10 text-white outline-none font-bold tracking-widest" />
                    </div>
                  </div>
                )}
                {resetStep === 3 && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-1">{t.newPass}</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                      <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="w-full p-4 pl-12 rounded-2xl bg-white/5 border border-white/10 text-white outline-none font-bold" />
                    </div>
                  </div>
                )}
                <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-4 rounded-2xl font-black transition-all">
                  {resetStep === 1 ? "Send Code" : resetStep === 2 ? "Verify Code" : "Update Password"}
                </button>
                <button type="button" onClick={() => { setMode('login'); setResetStep(1); }} className="w-full text-slate-400 text-sm font-bold">{t.backToLogin}</button>
              </form>
            </div>
          ) : (
            <form onSubmit={mode === 'signup' ? handleSignUpSubmit : handleLoginSubmit} className="space-y-6">
              {mode === 'signup' && (
                <>
                  <div className="space-y-4">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-1">{t.role}</label>
                    <div className="grid grid-cols-2 gap-4">
                      <button type="button" onClick={() => setRole('student')} className={`flex flex-col items-center gap-3 p-4 rounded-2xl border-2 transition-all ${role === 'student' ? 'border-indigo-500 bg-indigo-500/10 text-white' : 'border-white/5 bg-white/5 text-slate-400'}`}>
                        <GraduationCap size={24} /><span className="text-sm font-bold">{t.student}</span>
                      </button>
                      <button type="button" onClick={() => setRole('teacher')} className={`flex flex-col items-center gap-3 p-4 rounded-2xl border-2 transition-all ${role === 'teacher' ? 'border-indigo-500 bg-indigo-500/10 text-white' : 'border-white/5 bg-white/5 text-slate-400'}`}>
                        <UserIcon size={24} /><span className="text-sm font-bold">{t.teacher}</span>
                      </button>
                    </div>
                  </div>
                  {role === 'teacher' && (
                    <div className="space-y-2"><label className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-1">{t.teacherCode}</label>
                      <div className="relative"><Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                        <input type="text" required value={teacherCode} onChange={(e) => setTeacherCode(e.target.value)} placeholder="121206" className="w-full p-4 pl-12 rounded-2xl bg-white/5 border border-white/10 text-white outline-none font-bold" />
                      </div>
                    </div>
                  )}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-1">{t.fullName}</label>
                    <div className="relative">
                      <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                      <input type="text" required value={name} onChange={(e) => setName(e.target.value)} className="w-full p-4 pl-12 rounded-2xl bg-white/5 border border-white/10 text-white outline-none font-bold" />
                    </div>
                  </div>
                </>
              )}

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-1">Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                  <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full p-4 pl-12 rounded-2xl bg-white/5 border border-white/10 text-white outline-none font-bold" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-1">{t.password}</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                  <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full p-4 pl-12 rounded-2xl bg-white/5 border border-white/10 text-white outline-none font-bold" />
                </div>
              </div>

              {mode === 'login' && (
                <button type="button" onClick={() => setMode('forgot')} className="text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors block px-1">{t.forgotPass}</button>
              )}

              <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-3 transition-all shadow-xl shadow-indigo-500/20 active:scale-95">
                {mode === 'signup' ? t.signup : t.login}
                <ChevronRight size={20} />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
