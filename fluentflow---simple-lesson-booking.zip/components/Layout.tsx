
import React from 'react';
import { ViewState, User, Language } from '../types';
import { translations } from '../translations';
import { 
  Calendar, 
  LayoutDashboard, 
  Sparkles, 
  MessageSquare, 
  LogOut,
  Zap,
  Globe,
  User as UserIcon
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeView: ViewState;
  onViewChange: (view: ViewState) => void;
  user: User;
  onLogout: () => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeView, onViewChange, user, onLogout, language, onLanguageChange }) => {
  const t = translations[language];

  const menuItems = [
    { id: 'dashboard' as ViewState, label: t.dashboard, icon: <LayoutDashboard size={20} /> },
    { id: 'booking' as ViewState, label: t.book, icon: <Calendar size={20} />, hide: user.role === 'teacher' },
    { id: 'chat' as ViewState, label: t.messages, icon: <MessageSquare size={20} /> },
    { id: 'ai-buddy' as ViewState, label: t.ai, icon: <Sparkles size={20} /> },
  ];

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-[#f8fafc]">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-72 flex-col bg-white border-r border-slate-200 p-8 sticky top-0 h-screen">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-12 h-12 bg-gradient-to-tr from-indigo-600 to-violet-500 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-200">
            <Zap size={28} fill="currentColor" />
          </div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">FluentFlow</h1>
        </div>

        <nav className="flex-1 space-y-1">
          {menuItems.filter(item => !item.hide).map(item => (
            <NavItem 
              key={item.id}
              icon={item.icon} 
              label={item.label} 
              active={activeView === item.id} 
              onClick={() => onViewChange(item.id)} 
            />
          ))}
        </nav>

        <div className="pt-6 space-y-4">
          <div className="flex items-center justify-center gap-2 p-2 bg-slate-50 rounded-xl mb-4">
            <Globe size={16} className="text-slate-400" />
            <button onClick={() => onLanguageChange('en')} className={`text-xs font-bold px-2 py-1 rounded transition-colors ${language === 'en' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-indigo-600'}`}>EN</button>
            <button onClick={() => onLanguageChange('el')} className={`text-xs font-bold px-2 py-1 rounded transition-colors ${language === 'el' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-indigo-600'}`}>EL</button>
          </div>
          
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
            <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold shadow-inner">{user.name[0]}</div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-slate-900 truncate">{user.name}</p>
              <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">{user.role}</p>
            </div>
            <button onClick={onLogout} className="p-2 text-slate-400 hover:text-red-500 transition-colors" title={t.logout}><LogOut size={18} /></button>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="lg:hidden flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <Zap size={24} className="text-indigo-600" fill="currentColor" />
          <span className="font-black text-slate-900 tracking-tight">FluentFlow</span>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => onLanguageChange(language === 'en' ? 'el' : 'en')} className="text-xs font-black text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-lg uppercase">
            {language === 'en' ? 'EL' : 'EN'}
          </button>
          <button onClick={onLogout} className="p-2 text-slate-400 hover:text-red-500"><LogOut size={20} /></button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-24 lg:pb-0">
        <div className="max-w-6xl mx-auto p-6 md:p-12">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-2 py-3 flex justify-around items-center z-50 glass-effect">
        {menuItems.filter(item => !item.hide).map(item => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-2xl transition-all ${
              activeView === item.id ? 'text-indigo-600' : 'text-slate-400'
            }`}
          >
            <div className={activeView === item.id ? 'animate-bounce' : ''}>
              {item.icon}
            </div>
            <span className="text-[10px] font-black uppercase tracking-tighter">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

const NavItem: React.FC<{ icon: React.ReactNode; label: string; active: boolean; onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick} 
    className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 ${
      active 
      ? 'bg-indigo-600 text-white font-semibold shadow-xl shadow-indigo-100' 
      : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
    }`}
  >
    <div className={`${active ? 'scale-110' : ''} transition-transform`}>{icon}</div>
    <span className="tracking-tight">{label}</span>
  </button>
);
