
import React, { useState } from 'react';
import { Sparkles, Send, Loader2, BrainCircuit } from 'lucide-react';
import { generateLessonGoals } from '../services/geminiService';

export const AIBuddy: React.FC = () => {
  const [prompt, setPrompt] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ summary: string; objectives: string[]; encouragement: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    
    setIsLoading(true);
    const data = await generateLessonGoals(prompt);
    setResult(data);
    setIsLoading(false);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-50 text-indigo-600 font-semibold text-sm">
          <Sparkles size={16} />
          Powered by Gemini AI
        </div>
        <h2 className="text-3xl font-bold text-gray-900">AI Study Buddy</h2>
        <p className="text-gray-500">Tell me what you're struggling with or what your goals are for the next lesson.</p>
      </div>

      <div className="bg-white rounded-3xl border border-gray-100 shadow-xl p-6 md:p-8">
        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g., I have an interview next week and I'm nervous about technical terminology..."
            className="w-full h-32 p-4 rounded-2xl bg-gray-50 border-none focus:ring-2 focus:ring-indigo-500 resize-none transition-all placeholder:text-gray-400"
          />
          <button 
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 disabled:opacity-50 shadow-lg shadow-indigo-100"
          >
            {isLoading ? <Loader2 className="animate-spin" /> : <BrainCircuit size={20} />}
            {isLoading ? "Thinking..." : "Generate Lesson Plan"}
          </button>
        </form>

        {result && (
          <div className="mt-10 p-6 bg-indigo-50/50 rounded-2xl border border-indigo-100 space-y-6 animate-in slide-in-from-top-4">
            <div>
              <h4 className="font-bold text-indigo-900 mb-2">Focus Summary</h4>
              <p className="text-indigo-800 leading-relaxed">{result.summary}</p>
            </div>
            
            <div>
              <h4 className="font-bold text-indigo-900 mb-3">Suggested Objectives</h4>
              <ul className="space-y-3">
                {result.objectives.map((obj, i) => (
                  <li key={i} className="flex gap-3 text-indigo-800">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white text-indigo-600 flex items-center justify-center text-xs font-bold border border-indigo-100">
                      {i + 1}
                    </span>
                    {obj}
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-4 border-t border-indigo-100 italic text-indigo-600 text-center">
              "{result.encouragement}"
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
