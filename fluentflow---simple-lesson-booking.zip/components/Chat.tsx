
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Send, MoreVertical, Search, MessageSquare, User as UserIcon, Paperclip, FileText, ImageIcon, X, Download } from 'lucide-react';
import { User, ChatMessage, ChatFile } from '../types';

interface ChatProps {
  user: User;
  messages: ChatMessage[];
  onSendMessage: (text: string | undefined, file: ChatFile | undefined, receiverId: string) => void;
  partners: User[];
}

export const Chat: React.FC<ChatProps> = ({ user, messages, onSendMessage, partners }) => {
  const [activePartnerId, setActivePartnerId] = useState<string | null>(partners.length > 0 ? partners[0].id : null);
  const [msg, setMsg] = useState("");
  const [selectedFile, setSelectedFile] = useState<ChatFile | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activePartner = useMemo(() => partners.find(p => p.id === activePartnerId), [partners, activePartnerId]);

  const filteredMessages = useMemo(() => {
    if (!activePartnerId) return [];
    return messages.filter(m => 
      (m.senderId === user.id && m.receiverId === activePartnerId) || 
      (m.senderId === activePartnerId && m.receiverId === user.id)
    );
  }, [messages, user.id, activePartnerId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [filteredMessages]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedFile({
          name: file.name,
          type: file.type,
          size: file.size,
          data: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((!msg.trim() && !selectedFile) || !activePartnerId) return;
    onSendMessage(msg.trim() || undefined, selectedFile || undefined, activePartnerId);
    setMsg("");
    setSelectedFile(null);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };

  return (
    <div className="h-[calc(100vh-160px)] flex bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Sidebar */}
      {user.role === 'teacher' && (
        <div className="w-80 border-r border-slate-100 flex flex-col bg-slate-50/50">
          <div className="p-6 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <MessageSquare size={18} className="text-indigo-600" />
              Student Chats
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {partners.map(p => (
              <button
                key={p.id}
                onClick={() => setActivePartnerId(p.id)}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${
                  activePartnerId === p.id ? 'bg-white shadow-md border border-slate-100' : 'hover:bg-slate-100 text-slate-500'
                }`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg ${activePartnerId === p.id ? 'bg-indigo-600' : 'bg-slate-300'}`}>
                  {p.name[0]}
                </div>
                <div className="text-left flex-1 min-w-0">
                  <p className={`font-bold truncate ${activePartnerId === p.id ? 'text-slate-900' : ''}`}>{p.name}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {!activePartnerId ? (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-300">
            <MessageSquare size={64} className="opacity-10 mb-4" />
            <p className="font-bold">Select a student to chat</p>
          </div>
        ) : (
          <>
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                  <UserIcon size={20} />
                </div>
                <h3 className="font-bold text-slate-900">{activePartner?.name}</h3>
              </div>
            </div>

            <div className="flex-1 p-8 overflow-y-auto space-y-6 bg-slate-50/30">
              {filteredMessages.map((m) => (
                <div key={m.id} className={`flex ${m.senderId === user.id ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] p-5 rounded-[2rem] ${
                    m.senderId === user.id ? 'bg-indigo-600 text-white rounded-tr-none shadow-xl' : 'bg-white text-slate-800 rounded-tl-none border border-slate-100 shadow-sm'
                  }`}>
                    {m.file && (
                      <div className={`mb-3 p-4 rounded-2xl flex items-center gap-4 ${m.senderId === user.id ? 'bg-white/10' : 'bg-slate-50 border border-slate-100'}`}>
                        {m.file.type.startsWith('image/') ? (
                          <img src={m.file.data} alt={m.file.name} className="w-20 h-20 object-cover rounded-lg" />
                        ) : (
                          <div className={`p-3 rounded-lg ${m.senderId === user.id ? 'bg-white/20' : 'bg-indigo-50 text-indigo-600'}`}>
                            <FileText size={24} />
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold truncate">{m.file.name}</p>
                          <p className="text-[10px] opacity-60 uppercase font-black">{formatFileSize(m.file.size)}</p>
                        </div>
                        <a href={m.file.data} download={m.file.name} className={`p-2 rounded-lg ${m.senderId === user.id ? 'hover:bg-white/20' : 'hover:bg-slate-200'}`}>
                          <Download size={16} />
                        </a>
                      </div>
                    )}
                    {m.text && <p className="leading-relaxed font-medium">{m.text}</p>}
                    <p className={`text-[10px] mt-2 font-bold uppercase tracking-widest ${m.senderId === user.id ? 'text-indigo-200' : 'text-slate-400'}`}>{m.timestamp}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-6 border-t border-slate-100 bg-white">
              {selectedFile && (
                <div className="mb-4 p-4 bg-indigo-50 rounded-2xl flex items-center justify-between border border-indigo-100 animate-in slide-in-from-bottom-2">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-white rounded-xl text-indigo-600 shadow-sm"><FileText size={20} /></div>
                    <div>
                      <p className="text-xs font-bold text-indigo-900">{selectedFile.name}</p>
                      <p className="text-[10px] text-indigo-500 font-black uppercase">{formatFileSize(selectedFile.size)}</p>
                    </div>
                  </div>
                  <button onClick={() => setSelectedFile(null)} className="p-2 text-indigo-400 hover:text-red-500"><X size={20} /></button>
                </div>
              )}
              <form className="flex items-center gap-4" onSubmit={handleSubmit}>
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                <button type="button" onClick={() => fileInputRef.current?.click()} className="p-4 bg-slate-50 text-slate-500 rounded-2xl hover:bg-slate-100 transition-all"><Paperclip size={24} /></button>
                <div className="relative flex-1">
                  <input 
                    type="text" 
                    value={msg} 
                    onChange={(e) => setMsg(e.target.value)} 
                    placeholder="Type message..." 
                    className="w-full p-5 pr-16 rounded-2xl bg-slate-50 border-2 border-transparent focus:border-indigo-600 outline-none font-medium" 
                  />
                  <button disabled={!msg.trim() && !selectedFile} className="absolute right-3 top-1/2 -translate-y-1/2 p-3 bg-indigo-600 text-white rounded-xl disabled:opacity-20 shadow-lg"><Send size={20} /></button>
                </div>
              </form>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
