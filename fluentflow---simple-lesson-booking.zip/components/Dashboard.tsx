
import React, { useState } from 'react';
import { Lesson, UserRole, Subject, DayAvailability } from '../types';
import { 
  Clock, 
  Calendar, 
  Video, 
  TrendingUp, 
  DollarSign, 
  Trash2, 
  Zap, 
  Settings, 
  X, 
  Edit2,
  ChevronRight,
  Plus
} from 'lucide-react';

interface DashboardProps {
  lessons: Lesson[];
  role: UserRole;
  subjects: Subject[];
  onUpdateSubjects: (newSubjects: Subject[]) => void;
  meetingLink: string;
  onUpdateMeetingLink: (link: string) => void;
  userName: string;
  availability: DayAvailability[];
  onUpdateAvailability: (newAvailability: DayAvailability[]) => void;
  onCancelLesson: (id: string) => void;
  onRescheduleLesson: (id: string, newDate: Date) => void;
  credits?: number;
  onBookClick?: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ 
  lessons, 
  role, 
  subjects, 
  onUpdateSubjects, 
  meetingLink, 
  onUpdateMeetingLink,
  userName,
  availability,
  onUpdateAvailability,
  onCancelLesson,
  onRescheduleLesson,
  credits = 0,
  onBookClick
}) => {
  const [editingAvailability, setEditingAvailability] = useState(false);
  const [reschedulingId, setReschedulingId] = useState<string | null>(null);
  const [newReschedDate, setNewReschedDate] = useState("");
  const [newReschedTime, setNewReschedTime] = useState("");

  const upcoming = lessons.filter(l => l.status === 'upcoming');
  const earnings = lessons.reduce((acc, curr) => acc + curr.price, 0);
  const nextLesson = upcoming[0];

  const handleReschedule = (id: string) => {
    if (!newReschedDate || !newReschedTime) return;
    const date = new Date(newReschedDate + " " + newReschedTime);
    onRescheduleLesson(id, date);
    setReschedulingId(null);
  };

  if (role === 'teacher') {
    return (
      <div className="space-y-10 animate-in fade-in slide-in-from-top-4 duration-700">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-1">
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">Teacher Console</h2>
            <p className="text-slate-500 font-medium">Manage your schedule and track earnings.</p>
          </div>
          <button 
            onClick={() => setEditingAvailability(!editingAvailability)}
            className="group flex items-center gap-3 px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all"
          >
            <Settings size={20} className="group-hover:rotate-90 transition-transform duration-500" /> 
            {editingAvailability ? 'Save Changes' : 'Working Hours'}
          </button>
        </header>

        {editingAvailability && (
          <section className="bg-white p-10 rounded-[2.5rem] border-4 border-indigo-50 shadow-2xl space-y-8 animate-in zoom-in-95 duration-500">
            <div className="flex items-center gap-4">
               <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center">
                 <Clock size={24} />
               </div>
               <h3 className="text-2xl font-black text-slate-900">Weekly Working Hours</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {availability.map(day => (
                <div key={day.day} className={`flex items-center justify-between p-6 rounded-3xl transition-all ${day.enabled ? 'bg-indigo-50/50 border-2 border-indigo-100' : 'bg-slate-50 border-2 border-transparent opacity-60'}`}>
                  <div className="flex items-center gap-4">
                    <input 
                      type="checkbox" 
                      checked={day.enabled} 
                      onChange={() => onUpdateAvailability(availability.map(a => a.day === day.day ? { ...a, enabled: !a.enabled } : a))} 
                      className="w-6 h-6 rounded-lg accent-indigo-600" 
                    />
                    <span className="font-black text-slate-900">{day.day}</span>
                  </div>
                  {day.enabled && (
                    <div className="flex items-center gap-2">
                      <input 
                        type="time" 
                        value={day.start} 
                        onChange={e => onUpdateAvailability(availability.map(a => a.day === day.day ? { ...a, start: e.target.value } : a))} 
                        className="bg-white p-2 rounded-xl border border-indigo-100 font-bold text-slate-900" 
                      />
                      <span className="text-slate-400 font-black">—</span>
                      <input 
                        type="time" 
                        value={day.end} 
                        onChange={e => onUpdateAvailability(availability.map(a => a.day === day.day ? { ...a, end: e.target.value } : a))} 
                        className="bg-white p-2 rounded-xl border border-indigo-100 font-bold text-slate-900" 
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <StatCard label="Earnings" value={`$${earnings.toFixed(2)}`} icon={<DollarSign />} color="emerald" />
          <StatCard label="Upcoming" value={upcoming.length.toString()} icon={<Calendar />} color="orange" />
          <StatCard label="Experience" value="Certified" icon={<Zap />} color="indigo" />
        </div>

        <section className="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-10 border-b border-slate-50 flex justify-between items-center">
            <h3 className="text-2xl font-black text-slate-900">Upcoming Schedule</h3>
          </div>
          <div className="p-10 space-y-4">
            {upcoming.map(lesson => (
              <div key={lesson.id} className="group flex items-center justify-between p-6 rounded-[2rem] border border-slate-50 bg-slate-50/30 hover:bg-white hover:border-indigo-100 hover:shadow-xl transition-all duration-500">
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm">
                    <Calendar size={28} />
                  </div>
                  <div>
                    <h4 className="font-black text-xl text-slate-900">{lesson.subject}</h4>
                    <p className="text-slate-500 font-medium flex items-center gap-2">
                      <Clock size={16} /> {lesson.startTime.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <a href={meetingLink} target="_blank" className="p-4 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all"><Video size={20} /></a>
                  <button onClick={() => onCancelLesson(lesson.id)} className="p-4 bg-red-50 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all"><Trash2 size={20} /></button>
                </div>
              </div>
            ))}
            {upcoming.length === 0 && (
              <div className="text-center py-20">
                <div className="w-20 h-20 bg-slate-50 text-slate-200 rounded-full flex items-center justify-center mx-auto mb-6"><Calendar size={40} /></div>
                <p className="text-slate-400 text-lg font-medium">No sessions scheduled yet.</p>
              </div>
            )}
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-top-4 duration-700">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h2 className="text-5xl font-black text-slate-900 tracking-tight leading-tight">
            Hi, <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">{userName}</span>! 👋
          </h2>
          <p className="text-slate-500 mt-3 text-xl font-medium">Ready for your next learning milestone?</p>
        </div>
        <div className="flex gap-4">
           {credits > 0 && (
            <div className="bg-indigo-600 text-white px-8 py-4 rounded-[2rem] shadow-2xl shadow-indigo-200 flex items-center gap-3 font-black">
              <Zap size={20} fill="currentColor" />
              {credits} CREDITS AVAILABLE
            </div>
           )}
           <button onClick={onBookClick} className="bg-slate-900 text-white px-8 py-4 rounded-[2rem] font-black flex items-center gap-2 hover:bg-slate-800 transition-all shadow-xl">
              <Plus size={20} /> Book New
           </button>
        </div>
      </header>

      {nextLesson && (
        <div className="bg-slate-900 rounded-[3rem] p-12 text-white shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:scale-110 transition-transform duration-1000">
            <Zap size={200} fill="currentColor" />
          </div>
          <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-10">
            <div className="space-y-6 text-center lg:text-left">
              <span className="px-5 py-2 bg-indigo-500/20 text-indigo-300 rounded-full text-xs font-black uppercase tracking-widest border border-indigo-500/30">Upcoming Session</span>
              <h3 className="text-4xl font-black">{nextLesson.subject}</h3>
              <p className="text-slate-400 text-xl font-medium flex items-center justify-center lg:justify-start gap-3">
                <Clock size={24} className="text-indigo-400" /> {nextLesson.startTime.toLocaleString()}
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
               <a href={meetingLink} target="_blank" rel="noopener noreferrer" className="bg-indigo-600 text-white px-10 py-5 rounded-2xl font-black flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-500/20">
                 <Video size={24} /> Enter Classroom
               </a>
               <button onClick={() => setReschedulingId(nextLesson.id)} className="bg-white/10 text-white px-10 py-5 rounded-2xl font-black hover:bg-white/20 transition-all border border-white/10">
                 Reschedule
               </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        
        {/* Schedule List */}
        <section className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-10">
            <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
              <Calendar className="text-indigo-600" />
              My Schedule
            </h3>
            <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">{upcoming.length} Sessions</span>
          </div>
          
          <div className="space-y-4">
            {upcoming.map(lesson => (
              <div key={lesson.id} className="group p-6 rounded-[2rem] border-2 border-slate-50 hover:border-indigo-100 hover:bg-indigo-50/30 transition-all duration-500">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 bg-white border border-slate-100 text-indigo-600 rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                      <Calendar size={28} />
                    </div>
                    <div>
                      <h4 className="font-black text-xl text-slate-900 group-hover:text-indigo-600 transition-colors">{lesson.subject}</h4>
                      <p className="text-slate-500 font-medium">{lesson.startTime.toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 opacity-0 group-hover:opacity-100 translate-x-4 group-hover:translate-x-0 transition-all">
                    <button onClick={() => setReschedulingId(lesson.id)} className="p-3 bg-white text-indigo-600 rounded-xl hover:shadow-md transition-all">
                      <Edit2 size={20} />
                    </button>
                    <button onClick={() => onCancelLesson(lesson.id)} className="p-3 bg-white text-red-500 rounded-xl hover:shadow-md transition-all">
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>

                {reschedulingId === lesson.id && (
                  <div className="mt-6 p-6 bg-white rounded-3xl border-2 border-indigo-100 space-y-4 animate-in slide-in-from-top-4">
                    <div className="grid grid-cols-2 gap-3">
                      <input type="date" value={newReschedDate} onChange={e => setNewReschedDate(e.target.value)} className="p-4 bg-slate-50 border-none rounded-2xl font-bold" />
                      <input type="time" value={newReschedTime} onChange={e => setNewReschedTime(e.target.value)} className="p-4 bg-slate-50 border-none rounded-2xl font-bold" />
                    </div>
                    <div className="flex gap-3">
                      <button onClick={() => handleReschedule(lesson.id)} className="flex-1 bg-indigo-600 text-white font-black py-4 rounded-2xl shadow-lg">Confirm</button>
                      <button onClick={() => setReschedulingId(null)} className="flex-1 bg-slate-100 text-slate-500 font-black py-4 rounded-2xl">Cancel</button>
                    </div>
                  </div>
                )}
              </div>
            ))}
            {upcoming.length === 0 && (
              <div className="text-center py-20 border-2 border-dashed border-slate-100 rounded-[3rem]">
                <p className="text-slate-300 text-lg font-black uppercase tracking-widest">Adventure awaits</p>
                <p className="text-slate-400 mt-2 font-medium">Book your first session to start learning.</p>
              </div>
            )}
          </div>
        </section>

        {/* Action Sidebar */}
        <section className="space-y-8">
          <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden flex flex-col items-center text-center">
             <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mb-8 backdrop-blur-xl">
               <TrendingUp size={48} />
             </div>
             <h3 className="text-2xl font-black mb-4">Track Progress</h3>
             <p className="text-white/70 font-medium mb-8">See your learning statistics and completed hours.</p>
             <button className="w-full bg-white text-indigo-600 py-5 rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-slate-50 transition-all">
               View All <ChevronRight size={20} />
             </button>
          </div>

          <div className="bg-white p-8 rounded-[3rem] border border-slate-100 flex items-center gap-6">
             <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                <DollarSign size={28} />
             </div>
             <div>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Spent</p>
               <p className="text-2xl font-black text-slate-900">$0.00</p>
             </div>
          </div>
        </section>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ label: string; value: string; icon: React.ReactNode; color: 'indigo' | 'emerald' | 'orange' }> = ({ label, value, icon, color }) => {
  const colors = {
    indigo: 'bg-indigo-50 text-indigo-600',
    emerald: 'bg-emerald-50 text-emerald-600',
    orange: 'bg-orange-50 text-orange-600'
  };
  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-6 hover:translate-y-[-4px] transition-all">
      <div className={`w-20 h-20 rounded-[2rem] flex items-center justify-center ${colors[color]}`}>
        {React.cloneElement(icon as any, { size: 36, strokeWidth: 2.5 })}
      </div>
      <div>
        <p className="text-slate-400 text-sm font-black uppercase tracking-widest">{label}</p>
        <p className="text-4xl font-black text-slate-900 mt-1">{value}</p>
      </div>
    </div>
  );
};
