
import React, { useState, useEffect, useCallback } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { BookingView } from './components/BookingView';
import { AIBuddy } from './components/AIBuddy';
import { Chat } from './components/Chat';
import { LoginView } from './components/LoginView';
import { translations } from './translations';
import { ViewState, Lesson, Subject, User, ChatMessage, RegisteredUser, Notification, DayAvailability, Language } from './types';

const INITIAL_SUBJECTS: Subject[] = [
  { id: 's1', name: 'Standard Language Lesson', price: 25, description: 'One-on-one personalized session.' },
];

const INITIAL_AVAILABILITY: DayAvailability[] = [
  { day: 'Monday', enabled: true, start: '09:00', end: '20:00' },
  { day: 'Tuesday', enabled: true, start: '09:00', end: '20:00' },
  { day: 'Wednesday', enabled: true, start: '09:00', end: '20:00' },
  { day: 'Thursday', enabled: true, start: '09:00', end: '20:00' },
  { day: 'Friday', enabled: true, start: '09:00', end: '20:00' },
  { day: 'Saturday', enabled: false, start: '10:00', end: '15:00' },
  { day: 'Sunday', enabled: false, start: '10:00', end: '15:00' },
];

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('ff_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [lang, setLang] = useState<Language>(user?.language || 'en');
  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>(() => {
    const saved = localStorage.getItem('ff_registered_users');
    return saved ? JSON.parse(saved) : [];
  });

  const [view, setView] = useState<ViewState>(user ? 'dashboard' : 'login');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>(() => {
    const saved = localStorage.getItem('ff_lessons');
    return saved ? JSON.parse(saved).map((l: any) => ({ ...l, startTime: new Date(l.startTime) })) : [];
  });
  const [availability, setAvailability] = useState<DayAvailability[]>(() => {
    const saved = localStorage.getItem('ff_availability');
    return saved ? JSON.parse(saved) : INITIAL_AVAILABILITY;
  });
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('ff_chat_history');
    return saved ? JSON.parse(saved) : [];
  });
  const [meetingLink, setMeetingLink] = useState(() => localStorage.getItem('ff_meeting_link') || 'https://zoom.us/j/121206');

  useEffect(() => { localStorage.setItem('ff_lessons', JSON.stringify(lessons)); }, [lessons]);
  useEffect(() => { localStorage.setItem('ff_registered_users', JSON.stringify(registeredUsers)); }, [registeredUsers]);
  useEffect(() => { localStorage.setItem('ff_chat_history', JSON.stringify(chatMessages)); }, [chatMessages]);
  useEffect(() => { localStorage.setItem('ff_availability', JSON.stringify(availability)); }, [availability]);
  useEffect(() => { 
    if (user) {
      const updated = { ...user, language: lang };
      localStorage.setItem('ff_user', JSON.stringify(updated));
    } else {
      localStorage.removeItem('ff_user');
    }
  }, [user, lang]);

  const notify = useCallback((message: string, recipientEmail: string, type: 'email' | 'info' | 'success' = 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    setNotifications(prev => [...prev, { id, message, recipientEmail, type, timestamp: new Date() }]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 6000);
  }, []);

  const handleBookingComplete = (subject: string, date: Date, price: number, packageSize: number) => {
    if (!user) return;
    
    // Check if we are using existing credits or buying new
    let newCredits = user.credits || 0;
    
    if (newCredits > 0 && packageSize === 1) {
      // Used one existing credit
      newCredits -= 1;
    } else {
      // Bought a package (or single lesson if 0 credits), use one now, keep the rest
      newCredits += (packageSize - 1);
    }

    const newLesson: Lesson = { 
      id: Math.random().toString(36).substr(2, 9), 
      studentId: user.id, 
      startTime: date, 
      duration: 60, 
      subject, 
      status: 'upcoming', 
      price: price / packageSize 
    };

    const updatedUser = { ...user, credits: newCredits };
    setUser(updatedUser);
    setRegisteredUsers(prev => prev.map(u => u.id === user.id ? { ...u, credits: newCredits } : u));
    setLessons(prev => [...prev, newLesson].sort((a, b) => a.startTime.getTime() - b.startTime.getTime()));
    
    notify(lang === 'el' ? "Η κράτηση ολοκληρώθηκε!" : "Booking successful!", user.email, 'success');
    setView('dashboard');
  };

  const handleCancelLesson = (id: string) => {
    if (!window.confirm(lang === 'el' ? "Θέλετε σίγουρα να ακυρώσετε το μάθημα; Το credit θα επιστραφεί." : "Are you sure? Your credit will be refunded.")) return;
    
    setLessons(prev => prev.filter(l => l.id !== id));
    if (user && user.role === 'student') {
      const newCredits = (user.credits || 0) + 1;
      const updatedUser = { ...user, credits: newCredits };
      setUser(updatedUser);
      setRegisteredUsers(prev => prev.map(u => u.id === user.id ? { ...u, credits: newCredits } : u));
    }
  };

  const handleReschedule = (id: string, newDate: Date) => {
    setLessons(prev => prev.map(l => l.id === id ? { ...l, startTime: newDate } : l).sort((a, b) => a.startTime.getTime() - b.startTime.getTime()));
    notify(lang === 'el' ? "Η ώρα άλλαξε επιτυχώς!" : "Rescheduled successfully!", user?.email || "", 'success');
  };

  return (
    <div className="relative min-h-screen font-inter">
      {/* Toast Notifications */}
      <div className="fixed top-8 right-8 z-[100] flex flex-col gap-4 pointer-events-none max-w-sm w-full">
        {notifications.map(n => (
          <div key={n.id} className="pointer-events-auto bg-slate-900 text-white shadow-2xl rounded-[1.5rem] p-6 animate-in slide-in-from-right-8 duration-500 flex items-center gap-4 border border-white/10">
            <div className={`w-3 h-3 rounded-full shrink-0 ${n.type === 'success' ? 'bg-emerald-500' : 'bg-indigo-500'}`} />
            <div className="flex-1">
              <p className="text-xs font-black uppercase tracking-widest text-white/40 mb-1">Alert</p>
              <p className="text-sm font-bold leading-snug">{n.message}</p>
            </div>
          </div>
        ))}
      </div>

      {user && view !== 'login' ? (
        <Layout activeView={view} onViewChange={setView} user={user} onLogout={() => { setUser(null); setView('login'); }} language={lang} onLanguageChange={setLang}>
          {view === 'dashboard' && (
            <Dashboard 
              lessons={lessons} 
              role={user.role} 
              subjects={INITIAL_SUBJECTS} 
              onUpdateSubjects={() => {}} 
              meetingLink={meetingLink} 
              onUpdateMeetingLink={setMeetingLink} 
              userName={user.name} 
              availability={availability} 
              onUpdateAvailability={setAvailability} 
              onCancelLesson={handleCancelLesson} 
              onRescheduleLesson={handleReschedule} 
              credits={user.credits}
              onBookClick={() => setView('booking')}
            />
          )}
          {view === 'booking' && user.role === 'student' && (
            <BookingView 
              onComplete={handleBookingComplete} 
              subjects={INITIAL_SUBJECTS} 
              availability={availability} 
              language={lang} 
              userCredits={user.credits || 0}
            />
          )}
          {view === 'chat' && (
            <Chat 
              user={user} 
              messages={chatMessages} 
              onSendMessage={(t, f, rid) => {
                const msg: ChatMessage = { id: Date.now().toString(), senderId: user.id, receiverId: rid, senderName: user.name, senderRole: user.role, text: t, file: f, timestamp: new Date().toLocaleTimeString() };
                setChatMessages(prev => [...prev, msg]);
              }} 
              partners={user.role === 'teacher' ? registeredUsers.filter(u => u.role === 'student') : registeredUsers.filter(u => u.role === 'teacher')} 
            />
          )}
          {view === 'ai-buddy' && <AIBuddy />}
        </Layout>
      ) : (
        <LoginView 
          onLogin={(u) => { setUser(u); setView('dashboard'); setLang(u.language || 'en'); }} 
          onSignUp={(u) => { setRegisteredUsers(prev => [...prev, u]); setUser(u); setView('dashboard'); setLang(u.language || 'en'); }} 
          onResetPassword={(e, p) => setRegisteredUsers(prev => prev.map(u => u.email === e ? { ...u, passwordHash: p } : u))}
          onSendCode={(e, c) => notify(`Reset code: ${c}`, e, 'info')}
          registeredUsers={registeredUsers} 
          language={lang}
        />
      )}
    </div>
  );
};

export default App;
