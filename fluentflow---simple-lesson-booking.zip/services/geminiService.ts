
import { GoogleGenAI, Type } from "@google/genai";

// Initialize GoogleGenAI strictly following the guideline: new GoogleGenAI({ apiKey: process.env.API_KEY })
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLessonGoals = async (userPrompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userPrompt,
      config: {
        systemInstruction: "You are an expert language learning advisor. Based on the user's goals or current difficulties, suggest 3 specific learning objectives for their next 1-hour lesson. Keep it encouraging and structured.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            objectives: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            encouragement: { type: Type.STRING }
          },
          required: ["summary", "objectives", "encouragement"]
        }
      }
    });

    // Access the text property directly as a property, not a method, per guidelines.
    const text = response.text || '{}';
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
};
