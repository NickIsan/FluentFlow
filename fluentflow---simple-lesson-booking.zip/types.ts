
export type UserRole = 'student' | 'teacher';
export type Language = 'en' | 'el';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  credits?: number;
  language?: Language;
}

export interface RegisteredUser extends User {
  passwordHash: string;
}

export interface DayAvailability {
  day: string;
  enabled: boolean;
  start: string; // HH:mm (Teacher's local time)
  end: string;   // HH:mm (Teacher's local time)
}

export interface Lesson {
  id: string;
  studentId: string;
  startTime: Date;
  duration: number;
  subject: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  price: number;
}

export interface Subject {
  id: string;
  name: string;
  price: number;
  description: string;
}

export interface ChatFile {
  name: string;
  type: string;
  size: number;
  data: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  senderName: string;
  senderRole: UserRole;
  text?: string;
  file?: ChatFile;
  timestamp: string;
}

export type ViewState = 'dashboard' | 'booking' | 'chat' | 'ai-buddy' | 'settings' | 'login';

export interface Notification {
  id: string;
  message: string;
  subject?: string;
  recipientEmail: string;
  type: 'email' | 'info' | 'success';
  timestamp: Date;
}
